import 'package:get/get.dart';
import 'package:pearl/controller/userController.dart';


UserController userController = Get.put(UserController());