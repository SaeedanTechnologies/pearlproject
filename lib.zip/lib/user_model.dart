class Users {
  final String uid;
  final String? email;
  final bool? emailVerifed;
  Users(this.uid, this.email, this.emailVerifed);
}
