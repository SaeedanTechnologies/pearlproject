import 'package:flutter/material.dart';


Color yellowColor = Color(0xFFFFC755);
Color purpleColor = Color(0xFF852C5D);
